import React from "react";
import "./App.css";
import ListOfCourses from "./components/listofcourses.component";
class App extends React.Component {
  render() {
    return (
      <div>
        <h1>All Courses</h1>
        <ListOfCourses />
      </div>
    );
  }
}

export default App;
