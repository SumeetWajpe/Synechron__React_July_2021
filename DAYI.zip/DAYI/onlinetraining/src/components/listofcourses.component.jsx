import React from 'react';
import CourseModel from '../model/course.model';
import Course from './course.component';

class ListOfCourses extends React.Component {
    courses = [
        new CourseModel(1, "Vue", 5000, 5, 100, "https://i.ytimg.com/vi/DsuTwV0jwaY/maxresdefault.jpg"),
        new CourseModel(2, "React", 3000, 5, 900, "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg"),
        new CourseModel(3, "Node", 4000, 5, 1000, "https://buddy.works/guides/covers/test-nodejs-app/share-nodejs-logo.png"),
        new CourseModel(4, "Redux", 6000, 5, 600, "https://chriscourses.com/img/blog/redux/redux.jpg"),
        new CourseModel(5, "Angular", 4000, 5, 900, "https://lh3.googleusercontent.com/proxy/aHPg3Ou5OSGFGaTJOOiqRASFIu-AzKxexmaW31N5zIbY7Y0XCpO8RrvvcnYS5WP7VU-djBtsMCdd3gPUsf2lKe2LOw0R_U9T3B4gA8MpKkWLLYQq"),
    ];
    render() {
        let coursesToBeCreated = this.courses.map(course => <Course coursedetails={course} />)
        return <div className="row">
            {coursesToBeCreated}
        </div>
    }
}

export default ListOfCourses;