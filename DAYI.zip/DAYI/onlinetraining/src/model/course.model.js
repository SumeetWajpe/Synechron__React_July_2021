export default class CourseModel {
  constructor(id, title, price, rating, likes, imageUrl) {
    this.id = id;
    this.title = title;
    this.price = price;
    this.rating = rating;
    this.likes = likes;
    this.imageUrl = imageUrl;
  }
}
