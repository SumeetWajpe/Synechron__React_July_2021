import React from "react";
import "./App.css";
import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import NewCourse from "./components/newcourse.component";

class App extends React.Component {
  render() {
    return (
      <div>
        <ListOfCourses />
        {/* <Posts /> */}
        {/* <NewCourse /> */}
      </div>
    );
  }
}

export default App;
