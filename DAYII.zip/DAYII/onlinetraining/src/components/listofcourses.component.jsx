import React from 'react';
import CourseModel from '../model/course.model';
import Course from './course.component';
import NewCourse from "./newcourse.component";


class ListOfCourses extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            courses: [
                new CourseModel(1, "Vue", 5000, 5, 100, "https://i.ytimg.com/vi/DsuTwV0jwaY/maxresdefault.jpg"),
                new CourseModel(2, "React", 3000, 5, 900, "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg"),
                new CourseModel(3, "Node", 4000, 5, 1000, "https://buddy.works/guides/covers/test-nodejs-app/share-nodejs-logo.png"),
                new CourseModel(4, "Redux", 6000, 5, 600, "https://chriscourses.com/img/blog/redux/redux.jpg"),
                new CourseModel(5, "Angular", 4000, 5, 900, "https://lh3.googleusercontent.com/proxy/aHPg3Ou5OSGFGaTJOOiqRASFIu-AzKxexmaW31N5zIbY7Y0XCpO8RrvvcnYS5WP7VU-djBtsMCdd3gPUsf2lKe2LOw0R_U9T3B4gA8MpKkWLLYQq"),
            ]
        }
    };

    deleteACourse(theCourseId) {
        // ajax request to update/delete the server/db
        // if success ->
        console.log('calling setState()');
        let updatedCourseList = this.state.courses.filter(c => c.id !== theCourseId);
        this.setState({ courses: updatedCourseList });
    }

    componentWillMount() {
        // Initialize
        console.log('Within componentWillMount !');
    }
    componentDidMount() {
        // ajax request, framework integration
        console.log('Within componentDidMount !');
    }
    shouldComponentUpdate() {
        console.log('within shouldComponentUpdate !');
        console.log(arguments[1]);// state to be !
        if (arguments[1].courses.length == 0) {
            return false;
        }
        return true;
    }
    componentWillUpdate() {
        console.log('within componentWillUpdate !');
    }

    componentDidUpdate() {
        console.log('within componentDidUpdate !');
    }

    render() {
        console.log('Render !');
        console.log(this.state);

        let coursesToBeCreated = this.state.courses.map(course =>
            <Course
                key={course.id}
                deleteHandler={(theId) => this.deleteACourse(theId)}
                coursedetails={course}
            />)
        return (
            <div >
                <h2>New Course : </h2>
                <NewCourse />
                <h2>All Courses</h2>

                <div className="row">
                    {coursesToBeCreated}
                </div>
            </div>
        )
    }
}

export default ListOfCourses;