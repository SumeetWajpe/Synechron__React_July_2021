import React from 'react';
import CourseModel from '../model/course.model';


class NewCourse extends React.Component {
    constructor(props) {
        super(props);
        // this.txtRef = React.createRef();
        this.state = { id: 0, title: "", price: 0, likes: 0, rating: 0, imageUrl: "" };
    }
    render() {
        return <div>
            <form >
                Id : <input type="text" className="form-control" value={this.state.id} onChange={(e) => this.setState({ id: e.target.value })} />
                Title :<input type="text" className="form-control" value={this.state.title} onChange={(e) => this.setState({ title: e.target.value })} />
                Price :<input type="text" className="form-control" value={this.state.price} onChange={(e) => this.setState({ price: e.target.value })} />
                Likes:<input type="text" className="form-control" value={this.state.likes} onChange={(e) => this.setState({ likes: e.target.value })} />
                Rating:<input type="text" className="form-control" value={this.state.rating} onChange={(e) => this.setState({ rating: e.target.value })} />
                Image Url:<input type="text" className="form-control" value={this.state.imageUrl} onChange={(e) => this.setState({ imageUrl: e.target.value })} />

                <button className="btn btn-success mt-2">
                    Add
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-plus-circle m-1" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                    </svg>
                </button>

            </form>

        </div>
    }
}


// Uncontrolled Component
// class NewCourse extends React.Component {
//     constructor(props) {
//         super(props);
//         this.txtRef = React.createRef();
//         this.state = { name: '' };
//     }
//     render() {
//         return <div>
//             <input type="text" ref={this.txtRef} />
//             <h1>{this.state.name}</h1>

//             <input type="button" value="Add" onClick={() => {
//                 // console.log(this.txtRef.current.value);
//                 this.setState({ name: this.txtRef.current.value });
//             }} />
//         </div>
//     }
// }

export default NewCourse;