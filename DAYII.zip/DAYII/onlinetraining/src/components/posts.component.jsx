import axios from 'axios';
import React from 'react';

class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = { allPosts: [] };
    }
    componentDidMount() {
        let aPromise = axios.get('https://jsonplaceholder.typicode.com/posts');
        aPromise.then((response) => {
            this.setState({ allPosts: response.data });
        }).catch(function (err) {
            console.log(err);
        });
    }
    render() {
        let postsToBeCreated = this.state.allPosts.map(post => <li className="list-group-item" key={post.id}>{post.title}</li>);

        return <div>
            <h1> All Posts !</h1>
            <ul className="list-group"> {
                this.state.allPosts.length ? postsToBeCreated : <img
                    height="200px" width="200px" src="https://c.tenor.com/I6kN-6X7nhAAAAAj/loading-buffering.gif" alt="Loading.." />
            }</ul>
        </div>
    }
}

export default Posts;