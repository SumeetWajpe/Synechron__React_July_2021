import React from "react";
import "./App.css";
import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import NewCourse from "./components/newcourse.component";
import BasicFunctional from "./components/functional.basic";
import Counter from "./components/state.hooks";
import PostsWithEffect from "./components/postswithhooks";
import { BrowserRouter, Switch, Route, Redirect, Link } from "react-router-dom";
import PostDetails from "./components/post.details.component";

class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        {/* <a href="/">Courses</a>|<a href="/posts">Posts</a> |
        <a href="/postseffects">Posts(With Effect)</a> | */}
        {/* OR */}
        {/* <Link to="/">Courses</Link> |<Link to="/newcourse">New Course</Link> |
        <Link to="/posts">Posts</Link>|
        <Link to="/postseffects">Posts(With Effect)</Link> */}

        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container-fluid">
            <Link className="navbar-brand" to="/">
              Online Tuts
            </Link>

            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" aria-current="page" to="/">
                    Courses
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/newcourse">
                    New Course
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/posts">
                    Posts
                  </Link>
                </li>

                <li className="nav-item">
                  <Link className="nav-link" to="/postseffects">
                    Posts (With Effects)
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <Switch>
          <Route path="/" component={ListOfCourses} exact></Route>
          <Route path="/newcourse" component={NewCourse}></Route>
          <Route path="/posts" component={Posts}></Route>
          <Route path="/postseffects" component={PostsWithEffect}></Route>
          <Route path="/postdetails/:pid" component={PostDetails}></Route>
          <Route
            path="/functional"
            render={() => <BasicFunctional msg="Hola !" />}
          />

          <Route path="**" render={() => <Redirect to="/" />} />
          {/* <Route path='**' component={ErrorComponent}></Route> */}
          {/* <Route
            path="**"
            render={() => (
              <h1 style={{ color: "red" }} classNameName="alert alert-danger">
                404 ! Resource not found !
              </h1>
            )}
          ></Route> */}
        </Switch>
      </BrowserRouter>
    );
  }
}

export default App;
