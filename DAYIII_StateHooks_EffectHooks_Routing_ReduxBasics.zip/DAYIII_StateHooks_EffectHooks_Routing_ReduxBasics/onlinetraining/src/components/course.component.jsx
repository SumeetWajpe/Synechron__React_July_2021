import React from 'react';

class Course extends React.Component {
    constructor(props) {
        super(props);
        this.incrementLikes = this.incrementLikes.bind(this);
        this.state = { currLikes: this.props.coursedetails.likes };
    }

    incrementLikes() {
        // incrementing the likes !
        // this.props.coursedetails.likes++
        console.log('U Clicked !');
        console.log(this);
        // this.props.coursedetails.likes += 1;// props are readonly
        // this.state.currLikes += 1; // state are immutable !
        this.setState({ currLikes: this.state.currLikes + 1 });
    }
    componentWillUnmount() {
        console.log('Unmounting.. (Course)');
    }
    render() {
        console.log(this.state);
        return <div className="col-sm-6 col-md-4">
            <div className="card m-2 p-2">
                <img src={this.props.coursedetails.imageUrl} alt={this.props.coursedetails.title} />
                <div className="card-body">
                    <h3 className="card-title">{this.props.coursedetails.title}</h3>
                    <p className="card-text">Price : {this.props.coursedetails.price}</p>
                    <p className="card-text">Rating : {this.props.coursedetails.rating}</p>
                    <p>{this.state.currDislikes}</p>
                    <button className="btn btn-primary"
                        onClick={this.incrementLikes}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-hand-thumbs-up-fill" viewBox="0 0 16 16">
                            <path d="M6.956 1.745C7.021.81 7.908.087 8.864.325l.261.066c.463.116.874.456 1.012.965.22.816.533 2.511.062 4.51a9.84 9.84 0 0 1 .443-.051c.713-.065 1.669-.072 2.516.21.518.173.994.681 1.2 1.273.184.532.16 1.162-.234 1.733.058.119.103.242.138.363.077.27.113.567.113.856 0 .289-.036.586-.113.856-.039.135-.09.273-.16.404.169.387.107.819-.003 1.148a3.163 3.163 0 0 1-.488.901c.054.152.076.312.076.465 0 .305-.089.625-.253.912C13.1 15.522 12.437 16 11.5 16H8c-.605 0-1.07-.081-1.466-.218a4.82 4.82 0 0 1-.97-.484l-.048-.03c-.504-.307-.999-.609-2.068-.722C2.682 14.464 2 13.846 2 13V9c0-.85.685-1.432 1.357-1.615.849-.232 1.574-.787 2.132-1.41.56-.627.914-1.28 1.039-1.639.199-.575.356-1.539.428-2.59z" />
                        </svg>{this.state.currLikes}</button>
                    <button className="btn btn-danger m-1" onClick={() => this.props.deleteHandler(this.props.coursedetails.id)}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-trash-fill" viewBox="0 0 16 16">
                            <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    }
}

export default Course;