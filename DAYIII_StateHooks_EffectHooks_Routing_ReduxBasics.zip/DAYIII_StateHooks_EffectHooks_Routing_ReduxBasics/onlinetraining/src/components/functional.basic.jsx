// 1. No render method !
// 2. No State*  16.8+ (State Hooks)
// 3. No LifeCycle methods* (Effect Hooks)



// function BasicFunctionalComponent(props) {
//     return <h1>{props.msg}</h1>
// }


// var BasicFunctionalComponent = function (props) {
//     return <h1>{props.msg}</h1>
// }

var BasicFunctionalComponent = (props) => <h1>{props.msg}</h1>

export default BasicFunctionalComponent;
