import React from 'react'

const PostDetails = (props) => {
    // console.log(props.match.params.pid);
    let { match: { params: { pid } } } = props; // ES6 destructuring with objects !
    return (
        <div>
            <h1>Post Details for {pid}</h1>
        </div>
    )
}

export default PostDetails;