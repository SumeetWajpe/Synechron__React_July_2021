import React, { useEffect, useState } from 'react';
import axios from 'axios';
// useEffect(callback) -> 1. Initial Render done ! (componentdidmount) 
//2. After State has changed (render) (componentdidupdate)

const PostsWithEffect = (props) => {
    let [allPosts, setAllPosts] = useState([]);
    let [postId, setPostId] = useState(1);
    useEffect(() => {
        console.log('Fetching Posts !');
        let aPromise = axios.get('https://jsonplaceholder.typicode.com/posts/' + postId);
        aPromise.then((response) => {
            setAllPosts(response.data);
        }).catch(function (err) {
            console.log(err);
        });
    }, [postId]); // [] -> dependencies (Object,variable,array)

    console.log('Rendering JSX !');
    return (
        <div>
            <h1>All Posts</h1>
            <h2>{postId}</h2>
            <input type="button" value="++" onClick={() => setPostId(postId + 1)} />
            <br />
            {/* <ul className="list-group">{
                allPosts.map(post => <li className="list-group-item" key={post.id}>{post.title}</li>)
            }
            </ul> */}

            {
                allPosts.title
            }
        </div>
    )
}

export default PostsWithEffect;