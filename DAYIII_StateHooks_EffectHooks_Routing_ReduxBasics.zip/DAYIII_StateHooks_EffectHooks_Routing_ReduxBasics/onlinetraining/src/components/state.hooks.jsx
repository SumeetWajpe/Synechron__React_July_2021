import React, { useState } from 'react'

// 1. ctor - > this.state = {count:0}
// 2. onClick -> this.setState({count:this.state.count+1})

// 1. useState() -> returns an array -> [count,countChanger] = [10,function(){...}]


export const Counter = (props) => {
    let [myState, setCounterOrAge] = useState({ count: 10, age: 35 }); // ES6 -> Destructuring

    return (
        <div>
            <h1>{myState.count}</h1>
            <h1>{myState.age}</h1>

            <input type="button" value="Count++" className="btn btn-primary"
                onClick={() => setCounterOrAge({ ...myState, count: myState.count + 1, age: myState.age + 10 })}
            />
            <hr />
            {/* <h1>{age}</h1>
            <input type="button" value="Age ++" className="btn btn-primary"
                onClick={() => anyOtherName(age + 10)}
            /> */}
        </div>
    )
}

export default Counter;