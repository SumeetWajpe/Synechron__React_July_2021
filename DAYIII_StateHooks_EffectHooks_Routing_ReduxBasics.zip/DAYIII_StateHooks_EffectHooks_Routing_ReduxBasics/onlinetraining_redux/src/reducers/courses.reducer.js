export default function courses(defStore = [], action) {
  console.log("Within Courses Reducer !");
  return defStore; // new Store object
}
