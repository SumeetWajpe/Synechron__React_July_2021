export default function posts(defStore = [], action) {
  console.log("Within Posts Reducer !");
  return defStore; // new Store object
}
