export function IncrementLikes() {
  return { type: "INCREMENT_LIKES" };
}
export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}
export function AddCourse() {
  return { type: "ADD_COURSE" };
}
