import "./App.css";
import ListOfCourses from "./listofcourse.component";

function App(props) {
  return <ListOfCourses allCourses={props.allCourses} />;
}

export default App;
