import { func } from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as AllActions from "../actions/actionCreators";
import App from "./App";

const mapStateToProps = (store) => {
  return {
    allCourses: store.courses,
    allPosts: store.posts,
  };
};

const mapDispatchToProps = (dispatch) => {
  return bindActionCreators(AllActions, dispatch);
};

let HOCApp = connect(mapStateToProps, mapDispatchToProps)(App);

export default HOCApp;

// function Outer() {
//   return function (msg) {
//     console.log(msg);
//   };
// }

// Outer()("Hello !"); // Function Currying !
