import React from "react";
import Course from "./course.component";

const ListOfCourses = (props) => {
  let coursesToBeCreated = props.allCourses.map((course) => (
    <Course key={course.id} coursedetails={course} />
  ));
  return (
    <div>
      <h2>All Courses</h2>

      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
};

export default ListOfCourses;
