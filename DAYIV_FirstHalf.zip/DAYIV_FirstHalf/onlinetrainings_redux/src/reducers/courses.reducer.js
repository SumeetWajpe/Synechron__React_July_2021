export default function courses(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within Courses Reducer !");
      return defStore; // new Store object
    case "DELETE_PRODUCT":
      console.log("Within Courses Reducer !");
      return defStore; // new Store object
    case "ADD_COURSE":
      console.log("Within Courses Reducer !");
      return defStore; // new Store object
    default:
      return defStore;
  }
}
