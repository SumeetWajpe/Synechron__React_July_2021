export default function posts(defStore = [], action) {
  switch (action.type) {
    case "ADD_POST":
      console.log("Within Posts Reducer !");
      console.log(action);
      return defStore; // new Store object
    default:
      return defStore;
  }
}
