import CourseModel from "../model/course.model";
import { createStore } from "redux";
import rootReducer from "../reducers/rootReducer";

let defaultStoreData = {
  courses: [
    new CourseModel(
      1,
      "Vue",
      5000,
      5,
      100,
      "https://i.ytimg.com/vi/DsuTwV0jwaY/maxresdefault.jpg"
    ),
    new CourseModel(
      2,
      "React",
      3000,
      5,
      900,
      "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg"
    ),
    new CourseModel(
      3,
      "Node",
      4000,
      5,
      1000,
      "https://buddy.works/guides/covers/test-nodejs-app/share-nodejs-logo.png"
    ),
    new CourseModel(
      4,
      "Redux",
      6000,
      5,
      600,
      "https://chriscourses.com/img/blog/redux/redux.jpg"
    ),
    new CourseModel(
      5,
      "Angular",
      4000,
      5,
      900,
      "https://bs-uploads.toptal.io/blackfish-uploads/blog/post/seo/og_image_file/og_image/15991/top-18-most-common-angularjs-developer-mistakes-41f9ad303a51db70e4a5204e101e7414.png"
    ),
  ],
  posts: [{ id: 1, title: "First Post !" }],
};

var store = createStore(rootReducer, defaultStoreData);
export default store;
